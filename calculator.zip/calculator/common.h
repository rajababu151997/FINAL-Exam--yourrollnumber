#ifndef COMMON_H
#define COMMON_H

#define APP_NAME "Calculator"
#define VERSION "1.0"

#endif
