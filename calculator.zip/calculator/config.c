#include "config.h"

void loadConfig(AppConfig *config) {
    config->enableLogging = 1; // Always on for this demo
}
