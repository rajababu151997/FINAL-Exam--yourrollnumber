#ifndef IO_H
#define IO_H

void getInput(char *buffer, int size);
void printResult(const char *label, float value);

#endif
