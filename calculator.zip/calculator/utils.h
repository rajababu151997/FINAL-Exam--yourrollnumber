#ifndef UTILS_H
#define UTILS_H

int isNumber(const char *str);
void trim(char *str);

#endif
