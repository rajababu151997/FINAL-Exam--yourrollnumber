#ifndef LOGGER_H
#define LOGGER_H

void logMessage(const char *msg);
void logValue(const char *label, float value);

#endif
